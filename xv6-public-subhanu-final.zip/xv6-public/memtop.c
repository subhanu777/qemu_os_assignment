#include "types.h"
#include "stat.h"
#include "user.h"
#include "date.h"

int main(int argc,char *argv[])
{
	//printf(1,"Hi subhanu");
	memtop();
	exit();
}
