#include "types.h"
#include "date.h"
#include "user.h"
int main(int argc, char *argv[])
{
	ps_sys();
	exit();	
}











