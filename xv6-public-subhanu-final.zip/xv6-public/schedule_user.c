#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

int main(int argc, char **argv)
{
    int i,pid;
    int n = atoi(argv[1]); 
    if(n<=2)
	exit();
    else
    {
	for(i=0;i<n;i++)
	{
		pid=fork();
		if(pid<0)
			printf(1,"fork failed");
		else
			wait();
	}
	int p = getpid();
	int k = p%3;
	if(k==0)
	{
		for(int j=0;j<100000;j++)
		{
			printf(1,"ok1");
		}
	}
	else if(k==1)
	{
		for(int j=0;j<100;j++)
		{
			for(int l=0;l<100000;l++)
			{
				printf(1,"ok2");
			}
			//yield();
		}
	}
	else
	{
		for(int l=0;l<1000;l++)
		{
			printf(1,"ok3");
			sleep(1);
		}
	}	    
    }
    exit();
}
