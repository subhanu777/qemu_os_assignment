typedef unsigned int   uint;
typedef unsigned short ushort;
typedef unsigned char  uchar;
typedef int bool;
#define true (1)
#define false (0)


typedef uint pde_t;
